# Zeta Live Translator V1.9

Versión corregida para traducir subtítulos sobre otras apps.

## Cambios V1.9

- Modo **Auto → Español** por defecto.
- OCR probado por idioma: Inglés, Chino, Japonés y Coreano.
- Se quitó el aviso grande de “No se detectó texto” para que no moleste en video.
- El cuadro ya no se recrea por accidente al tocar fuera.
- El cuadro se mueve tocando dentro y arrastrando.
- El cuadro se estira desde cualquiera de los puntos morados.
- Después de traducir, desaparece el cuadro y queda solo el subtítulo.
- Primera vez: usar internet y tocar **Preparar offline** para descargar modelos.

## Uso rápido

1. Abrir la app con internet.
2. Tocar **Preparar offline**.
3. Activar **Permiso sobre otras apps**.
4. Tocar **Iniciar traductor**.
5. En el video tocar **Área**.
6. Mover o estirar el cuadro sobre el subtítulo.
7. Tocar **OK**.
8. Tocar **Trad.** o **Vivo**.

Si el texto no aparece, no saldrá aviso grande en medio; solo ajusta el cuadro más cerca del subtítulo o pausa el video.


NOVEDAD V1.9:
- Subtítulo con fondo negro semitransparente y letras blancas.
- El cuadro ya no se recrea al tocar fuera; solo se mueve o estira.
- Traducción Auto→Español para Inglés, Chino, Japonés y Coreano.


NOVEDAD V1.9:
- Subtítulo estable: ya no se oculta en cada captura, por eso no parpadea.
- La barra puede ocultarse para capturar, pero el subtítulo queda fijo.
- El resultado se coloca fuera del cuadro OCR para que no se lea a sí mismo.
- Limpieza mejorada para inglés mezclado con chino/japonés/coreano.
- Correcciones: at home, put your clothes on, so I pretend I don't know anything.
