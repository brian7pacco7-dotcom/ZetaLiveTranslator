package com.geozeta.livetranslator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.nio.ByteBuffer;

public class OverlayTranslatorService extends Service {
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_DATA = "projection_data";

    private static final String CHANNEL_ID = "zeta_live_translator";
    private static final int NOTIFICATION_ID = 781;

    private WindowManager windowManager;
    private Handler handler;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private int screenWidth;
    private int screenHeight;
    private int screenDensity;

    private LinearLayout toolbar;
    private TextView areaBtn;
    private TextView liveBtn;
    private TextView langBtn;
    private TextView subtitleBtn;
    private TextView statusView;
    private TextView subtitleView;
    private SelectorOverlayView selectorView;
    private WindowManager.LayoutParams toolbarParams;
    private WindowManager.LayoutParams subtitleParams;
    private WindowManager.LayoutParams selectorParams;
    private WindowManager.LayoutParams statusParams;

    private final TranslatorEngine engine = new TranslatorEngine();
    private Runnable statusHideRunnable;
    private Rect selectorRect;
    private boolean selecting = false;
    private boolean live = false;
    private boolean busy = false;
    private boolean subtitlesEnabled = true;
    private String lastSubtitleText = "";
    private String lastSubtitleSource = "";
    private String lastOriginalText = "";
    private String lastTranslatedText = "";
    private long lastTranslationCacheMs = 0L;
    private static final long REUSE_TRANSLATION_MS = 12000L;
    private String autoLockedMode = null;
    private long autoLockUntilMs = 0L;
    private static final long AUTO_LOCK_MS = 26000L;
    // Por defecto inicia en Auto → Español para leer Inglés, Chino, Japonés o Coreano sin cambiar cada vez.
    private int languageIndex = 0;
    private final String[] languageModes = new String[]{
            TranslatorEngine.MODE_AUTO,
            TranslatorEngine.MODE_CHINESE,
            TranslatorEngine.MODE_ENGLISH,
            TranslatorEngine.MODE_JAPANESE,
            TranslatorEngine.MODE_KOREAN
    };

    private final Runnable liveRunnable = new Runnable() {
        @Override public void run() {
            if (!live) return;
            translateOnce(false);
            handler.postDelayed(this, 1900);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        startForeground(NOTIFICATION_ID, buildNotification("Traductor listo"));
        readMetrics();
        selectorRect = defaultRect();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent data = intent.getParcelableExtra(EXTRA_DATA);
        if (resultCode != 0 && data != null) {
            MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            mediaProjection = manager.getMediaProjection(resultCode, data);
            mediaProjection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { stopSelf(); }
            }, handler);
            setupCapture();
            // No abrimos el cuadro automáticamente para que NO bloquee el celular.
            // El usuario toca "Área" cuando quiera seleccionar el subtítulo.
            showToolbar();
            // Sin aviso grande en medio. La barra queda lista y no molesta.
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void setupCapture() {
        releaseCaptureOnly();
        readMetrics();
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ZetaLiveTranslatorScreen",
                screenWidth,
                screenHeight,
                screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                handler
        );
    }

    private void readMetrics() {
        DisplayMetrics metrics = new DisplayMetrics();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            android.view.WindowMetrics wm = windowManager.getMaximumWindowMetrics();
            Rect bounds = wm.getBounds();
            screenWidth = bounds.width();
            screenHeight = bounds.height();
            screenDensity = getResources().getDisplayMetrics().densityDpi;
        } else {
            windowManager.getDefaultDisplay().getRealMetrics(metrics);
            screenWidth = metrics.widthPixels;
            screenHeight = metrics.heightPixels;
            screenDensity = metrics.densityDpi;
        }
    }

    private Rect defaultRect() {
        int w = Math.max(dp(260), (int) (screenWidth * 0.70f));
        int h = Math.max(dp(70), (int) (screenHeight * 0.13f));
        int left = (screenWidth - w) / 2;
        int top = (int) (screenHeight * 0.70f);
        return new Rect(left, top, left + w, Math.min(screenHeight - dp(16), top + h));
    }

    private void showToolbar() {
        if (toolbar != null) return;
        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(6), dp(5), dp(6), dp(5));
        toolbar.setBackgroundColor(Color.argb(210, 17, 24, 39));

        areaBtn = addButton(selecting ? "OK" : "Área");
        TextView translateBtn = addButton("Trad.");
        liveBtn = addButton("Vivo");
        subtitleBtn = addButton("Ocultar");
        langBtn = addButton(languageLabel(languageModes[languageIndex]) + "→ES");
        TextView closeBtn = addButton("×");

        areaBtn.setOnClickListener(v -> toggleSelector());
        translateBtn.setOnClickListener(v -> translateOnce(true));
        liveBtn.setOnClickListener(v -> toggleLive());
        subtitleBtn.setOnClickListener(v -> toggleSubtitles());
        langBtn.setOnClickListener(v -> cycleLanguage());
        closeBtn.setOnClickListener(v -> stopSelf());

        toolbarParams = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
        toolbarParams.gravity = Gravity.TOP | Gravity.START;
        toolbarParams.x = dp(12);
        toolbarParams.y = dp(38);
        toolbarParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        toolbar.setOnTouchListener(new View.OnTouchListener() {
            int startX;
            int startY;
            float touchX;
            float touchY;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = toolbarParams.x;
                        startY = toolbarParams.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        return false;
                    case MotionEvent.ACTION_MOVE:
                        toolbarParams.x = startX + (int) (event.getRawX() - touchX);
                        toolbarParams.y = startY + (int) (event.getRawY() - touchY);
                        safeUpdate(toolbar, toolbarParams);
                        return true;
                }
                return false;
            }
        });
        safeAdd(toolbar, toolbarParams);
    }

    private TextView addButton(String text) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(10), dp(7), dp(10), dp(7));
        b.setBackgroundColor(Color.TRANSPARENT);
        toolbar.addView(b, new LinearLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT));
        return b;
    }

    private void toggleSelector() {
        if (selecting) {
            hideSelector();
            selecting = false;
            areaBtn.setText("Área");
            showStatus("Área guardada", 900);
        } else {
            showSelector();
            selecting = true;
            areaBtn.setText("OK");
            showStatus("Ajusta y toca OK", 1200);
        }
    }

    private void showSelector() {
        if (selectorView != null) return;
        selectorView = new SelectorOverlayView(this, selectorRect);
        selectorView.setOnRectChangedListener(rect -> selectorRect = rect);
        selectorParams = overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        selectorParams.gravity = Gravity.TOP | Gravity.START;
        selectorParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        safeAdd(selectorView, selectorParams);
        bringToolbarToFront();
    }

    private void bringToolbarToFront() {
        if (toolbar != null && toolbarParams != null) {
            safeRemove(toolbar);
            safeAdd(toolbar, toolbarParams);
        }
    }

    private void hideSelector() {
        if (selectorView != null) {
            safeRemove(selectorView);
            selectorView = null;
        }
    }

    private void toggleLive() {
        live = !live;
        if (live) {
            if (selecting) toggleSelector();
            liveBtn.setText("Pausa");
            showStatus("En vivo", 650);
            handler.post(liveRunnable);
        } else {
            liveBtn.setText("Vivo");
            showStatus("Pausado", 650);
        }
    }

    private void toggleSubtitles() {
        subtitlesEnabled = !subtitlesEnabled;
        if (subtitleBtn != null) subtitleBtn.setText(subtitlesEnabled ? "Ocultar" : "Mostrar");
        if (!subtitlesEnabled) {
            clearSubtitle();
            showStatus("Subtítulos ocultos", 850);
        } else {
            showStatus("Subtítulos activos", 850);
        }
    }

    private void clearSubtitle() {
        lastSubtitleText = "";
        lastSubtitleSource = "";
        lastOriginalText = "";
        lastTranslatedText = "";
        lastTranslationCacheMs = 0L;
        if (subtitleView != null) {
            safeRemove(subtitleView);
            subtitleView = null;
        }
        subtitleParams = null;
    }

    private void cycleLanguage() {
        languageIndex = (languageIndex + 1) % languageModes.length;
        autoLockedMode = null;
        autoLockUntilMs = 0L;
        langBtn.setText(languageLabel(languageModes[languageIndex]) + "→ES");
        showStatus("Idioma: " + languageLabel(languageModes[languageIndex]) + " → Español", 1100);
    }

    private String languageLabel(String mode) {
        if (TranslatorEngine.MODE_AUTO.equals(mode)) return "Auto";
        if (TranslatorEngine.MODE_CHINESE.equals(mode)) return "Chino";
        if (TranslatorEngine.MODE_ENGLISH.equals(mode)) return "Inglés";
        if (TranslatorEngine.MODE_JAPANESE.equals(mode)) return "Japonés";
        if (TranslatorEngine.MODE_KOREAN.equals(mode)) return "Coreano";
        return "Auto";
    }

    private void translateOnce(boolean userRequested) {
        if (busy) return;
        if (selecting && userRequested) toggleSelector();
        if (mediaProjection == null || imageReader == null) {
            showStatus("Falta permiso de captura de pantalla", 1400);
            return;
        }

        String requestedMode = languageModes[languageIndex];
        String modeForRun = resolveModeForRun(requestedMode, userRequested);
        busy = true;
        hideAllForCleanCapture();
        handler.postDelayed(() -> captureAndTranslate(0, requestedMode, modeForRun), live ? 90 : 130);
    }

    private String resolveModeForRun(String requestedMode, boolean userRequested) {
        if (!TranslatorEngine.MODE_AUTO.equals(requestedMode)) return requestedMode;
        long now = System.currentTimeMillis();
        if (!userRequested && autoLockedMode != null && now < autoLockUntilMs) {
            return autoLockedMode;
        }
        return TranslatorEngine.MODE_AUTO;
    }

    private void hideAllForCleanCapture() {
        // La barra y el selector sí se ocultan para que el OCR no lea botones.
        // El subtítulo NO se oculta: así no parpadea. Se muestra fuera del cuadro OCR.
        if (toolbar != null) toolbar.setVisibility(View.INVISIBLE);
        if (selectorView != null) selectorView.setVisibility(View.INVISIBLE);
        if (statusView != null) statusView.setVisibility(View.INVISIBLE);
    }

    private void restoreAfterCapture() {
        if (toolbar != null) toolbar.setVisibility(View.VISIBLE);
        if (selectorView != null) selectorView.setVisibility(View.VISIBLE);
        if (statusView != null) statusView.setVisibility(View.VISIBLE);
    }

    private void captureAndTranslate(int attempt, String requestedMode, String modeForRun) {
        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) {
                if (attempt < 4) {
                    handler.postDelayed(() -> captureAndTranslate(attempt + 1, requestedMode, modeForRun), 80);
                } else {
                    restoreAfterCapture();
                    busy = false;
                    showStatus("No se pudo capturar la pantalla", 1100);
                }
                return;
            }
            Bitmap full = imageToBitmap(image);
            image.close();
            image = null;
            Rect cropRect = clampCrop(selectorRect, full.getWidth(), full.getHeight());
            Bitmap crop = Bitmap.createBitmap(full, cropRect.left, cropRect.top, cropRect.width(), cropRect.height());
            full.recycle();
            restoreAfterCapture();

            engine.process(crop, modeForRun, new TranslatorEngine.Callback() {
                @Override public void onSuccess(String original, String translated, String sourceName) {
                    crop.recycle();
                    busy = false;
                    updateAutoLock(requestedMode, sourceName);
                    showSubtitle(translated, sourceName);
                }

                @Override public void onError(String message) {
                    crop.recycle();
                    busy = false;
                    if (TranslatorEngine.MODE_AUTO.equals(requestedMode)) {
                        autoLockedMode = null;
                        autoLockUntilMs = 0L;
                    }
                    // No mostrar "No se detectó texto" porque molesta durante videos.
                    if (message == null || !message.toLowerCase().contains("no se detect")) {
                        showStatus(message, 1200);
                    }
                }
            });
        } catch (Exception e) {
            if (image != null) image.close();
            restoreAfterCapture();
            busy = false;
            showStatus("Error captura: " + e.getMessage(), 1800);
        }
    }

    private void updateAutoLock(String requestedMode, String sourceName) {
        if (!TranslatorEngine.MODE_AUTO.equals(requestedMode)) return;
        String mode = modeFromReadable(sourceName);
        if (mode != null) {
            autoLockedMode = mode;
            autoLockUntilMs = System.currentTimeMillis() + AUTO_LOCK_MS;
        }
    }

    private String modeFromReadable(String sourceName) {
        if (sourceName == null) return null;
        String s = sourceName.toLowerCase();
        if (s.contains("chino")) return TranslatorEngine.MODE_CHINESE;
        if (s.contains("inglés") || s.contains("ingles")) return TranslatorEngine.MODE_ENGLISH;
        if (s.contains("japon")) return TranslatorEngine.MODE_JAPANESE;
        if (s.contains("coreano")) return TranslatorEngine.MODE_KOREAN;
        return null;
    }

    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = rowStride - pixelStride * screenWidth;
        int bitmapWidth = screenWidth + rowPadding / pixelStride;
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, screenHeight, Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer(buffer);
        if (bitmapWidth != screenWidth) {
            Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight);
            bitmap.recycle();
            return cropped;
        }
        return bitmap;
    }

    private Rect clampCrop(Rect r, int maxW, int maxH) {
        int left = Math.max(0, Math.min(r.left, maxW - 2));
        int top = Math.max(0, Math.min(r.top, maxH - 2));
        int right = Math.max(left + 2, Math.min(r.right, maxW));
        int bottom = Math.max(top + 2, Math.min(r.bottom, maxH));
        return new Rect(left, top, right, bottom);
    }

    private void showSubtitle(String translated, String sourceName) {
        // El cuadro OCR desaparece. El subtítulo queda estable y NO se oculta al capturar.
        hideSelector();
        selecting = false;
        if (areaBtn != null) areaBtn.setText("Área");

        String text = makeSubtitleText(translated);
        if (text.length() == 0) return;

        if (!subtitlesEnabled) {
            lastSubtitleText = text;
            lastSubtitleSource = sourceName == null ? "" : sourceName;
            updateNotification((sourceName == null ? "Auto" : sourceName) + " → Español");
            return;
        }

        // Si una lectura sale sucia por OCR, no reemplaza el último subtítulo bueno.
        if (lastSubtitleText.length() > 0 && looksBadSubtitle(text)) {
            updateNotification((sourceName == null ? "Auto" : sourceName) + " → Español");
            return;
        }

        boolean sameSubtitle = isSameSubtitle(text, lastSubtitleText);

        if (subtitleView == null) {
            subtitleView = new TextView(this);
            subtitleView.setTextColor(Color.WHITE);
            subtitleView.setTextSize(19);
            subtitleView.setGravity(Gravity.CENTER);
            subtitleView.setPadding(dp(16), dp(10), dp(16), dp(10));
            subtitleView.setShadowLayer(dp(2), 0, 0, Color.argb(120, 0, 0, 0));
            GradientDrawable subtitleBg = new GradientDrawable();
            subtitleBg.setColor(Color.argb(155, 0, 0, 0));
            subtitleBg.setCornerRadius(dp(10));
            subtitleView.setBackground(subtitleBg);
            subtitleView.setIncludeFontPadding(false);
            subtitleView.setLineSpacing(0f, 1.05f);
            subtitleView.setMaxLines(3);
        }

        if (!sameSubtitle) {
            subtitleView.setText(text);
            lastSubtitleText = text;
        }
        lastSubtitleSource = sourceName == null ? "" : sourceName;

        if (subtitleParams == null) {
            subtitleParams = overlayParams(selectorRect.width(), WindowManager.LayoutParams.WRAP_CONTENT);
            subtitleParams.gravity = Gravity.TOP | Gravity.START;
            subtitleParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        }

        // Para que no parpadee ni se lea a sí mismo, el subtítulo se coloca fuera del cuadro OCR.
        int[] pos = subtitlePositionOutsideOcr();
        subtitleParams.x = pos[0];
        subtitleParams.y = pos[1];
        subtitleParams.width = pos[2];
        subtitleParams.height = WindowManager.LayoutParams.WRAP_CONTENT;

        if (subtitleView.getParent() == null) {
            safeAdd(subtitleView, subtitleParams);
        } else {
            safeUpdate(subtitleView, subtitleParams);
        }
        subtitleView.setVisibility(View.VISIBLE);
        updateNotification(sourceName + " → Español");
    }

    private int[] subtitlePositionOutsideOcr() {
        int w = Math.max(dp(260), Math.min(selectorRect.width(), screenWidth - dp(24)));
        int x = selectorRect.left + (selectorRect.width() - w) / 2;
        x = Math.max(dp(8), Math.min(x, screenWidth - w - dp(8)));

        int estimatedHeight = dp(68);
        int margin = dp(8);
        int y;
        if (selectorRect.top - estimatedHeight - margin > dp(8)) {
            y = selectorRect.top - estimatedHeight - margin;
        } else {
            y = selectorRect.bottom + margin;
        }
        y = Math.max(dp(8), Math.min(y, screenHeight - estimatedHeight - dp(8)));
        return new int[]{x, y, w};
    }

    private boolean isSameSubtitle(String a, String b) {
        String ka = subtitleKey(a);
        String kb = subtitleKey(b);
        if (ka.length() == 0 || kb.length() == 0) return false;
        if (ka.equals(kb)) return true;
        return (ka.contains(kb) || kb.contains(ka)) && Math.abs(ka.length() - kb.length()) < 10;
    }

    private String subtitleKey(String s) {
        if (s == null) return "";
        return s.toLowerCase()
                .replaceAll("[^a-záéíóúñü0-9]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private boolean looksBadSubtitle(String s) {
        if (s == null) return true;
        String t = s.trim();
        if (t.length() < 2) return true;
        if (t.matches(".*[A-Za-z]{2,}\\.{2,}.*")) return true;
        if (t.matches(".*\\([A-Za-z0-9.,;:_\\- ]{4,}\\).*")) return true;
        String key = subtitleKey(t);
        if (key.contains("dothes") || key.contains("btifmi") || key.contains("ffa")) return true;
        return false;
    }

    private String makeSubtitleText(String text) {
        if (text == null) return "";
        return text.replace("\r", " ")
                .replace("\n", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private void showStatus(String text, long durationMs) {
        if (text == null || text.trim().length() == 0) return;
        String lower = text.toLowerCase();
        if (lower.contains("no se detect")) return;

        if (statusView == null) {
            statusView = new TextView(this);
            statusView.setTextColor(Color.WHITE);
            statusView.setTextSize(11);
            statusView.setGravity(Gravity.CENTER);
            statusView.setPadding(dp(8), dp(4), dp(8), dp(4));
            statusView.setBackgroundColor(Color.argb(175, 17, 24, 39));
            statusParams = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
            statusParams.gravity = Gravity.TOP | Gravity.START;
            statusParams.x = toolbarParams != null ? toolbarParams.x : dp(12);
            statusParams.y = toolbarParams != null ? toolbarParams.y + dp(46) : dp(86);
            statusParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            safeAdd(statusView, statusParams);
        } else if (statusParams != null) {
            statusParams.x = toolbarParams != null ? toolbarParams.x : dp(12);
            statusParams.y = toolbarParams != null ? toolbarParams.y + dp(46) : dp(86);
            safeUpdate(statusView, statusParams);
        }
        statusView.setText(text);
        statusView.setVisibility(View.VISIBLE);
        if (statusHideRunnable != null) handler.removeCallbacks(statusHideRunnable);
        statusHideRunnable = () -> {
            if (statusView != null) statusView.setVisibility(View.GONE);
        };
        handler.postDelayed(statusHideRunnable, durationMs);
    }

    private WindowManager.LayoutParams overlayParams(int width, int height) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                width,
                height,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        return params;
    }

    private Notification buildNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Zeta Live Translator", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            return new Notification.Builder(this, CHANNEL_ID)
                    .setSmallIcon(com.geozeta.livetranslator.R.drawable.ic_stat_zeta)
                    .setContentTitle("Zeta Live Translator")
                    .setContentText(text)
                    .setOngoing(true)
                    .build();
        }
        return new Notification.Builder(this)
                .setSmallIcon(com.geozeta.livetranslator.R.drawable.ic_stat_zeta)
                .setContentTitle("Zeta Live Translator")
                .setContentText(text)
                .setOngoing(true)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification(text));
    }

    private void safeAdd(View view, WindowManager.LayoutParams params) {
        try { windowManager.addView(view, params); } catch (Exception ignored) { }
    }

    private void safeUpdate(View view, WindowManager.LayoutParams params) {
        try { windowManager.updateViewLayout(view, params); } catch (Exception ignored) { }
    }

    private void safeRemove(View view) {
        try { windowManager.removeView(view); } catch (Exception ignored) { }
    }

    private void releaseCaptureOnly() {
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
    }

    @Override
    public void onDestroy() {
        live = false;
        if (toolbar != null) safeRemove(toolbar);
        if (selectorView != null) safeRemove(selectorView);
        if (subtitleView != null) safeRemove(subtitleView);
        if (statusView != null) safeRemove(statusView);
        releaseCaptureOnly();
        if (mediaProjection != null) {
            try { mediaProjection.stop(); } catch (Exception ignored) { }
            mediaProjection = null;
        }
        super.onDestroy();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        readMetrics();
        selectorRect = defaultRect();
        setupCapture();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
