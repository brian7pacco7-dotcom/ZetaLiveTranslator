package com.geozeta.livetranslator;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class TranslatorEngine {
    public static final String MODE_AUTO = "auto";
    public static final String MODE_CHINESE = TranslateLanguage.CHINESE;
    public static final String MODE_ENGLISH = TranslateLanguage.ENGLISH;
    public static final String MODE_JAPANESE = TranslateLanguage.JAPANESE;
    public static final String MODE_KOREAN = TranslateLanguage.KOREAN;

    public interface Callback {
        void onSuccess(String original, String translated, String sourceName);
        void onError(String message);
    }

    private final Pattern cjkPattern = Pattern.compile("[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF]");
    private final Pattern chinesePattern = Pattern.compile("[\\u3400-\\u9FFF]");
    private final Pattern japanesePattern = Pattern.compile("[\\u3040-\\u30FF]");
    private final Pattern koreanPattern = Pattern.compile("[\\uAC00-\\uD7AF]");
    private final Pattern latinPattern = Pattern.compile("[A-Za-z]");

    public void process(Bitmap crop, String mode, Callback callback) {
        if (crop == null || crop.isRecycled()) {
            callback.onError("No se pudo leer el recorte.");
            return;
        }
        if (MODE_AUTO.equals(mode)) {
            processAuto(crop, callback);
        } else {
            processFixed(crop, mode, callback);
        }
    }

    private void processFixed(Bitmap crop, String mode, Callback callback) {
        Bitmap prepared = prepareForOcr(crop);
        recognize(prepared, mode, new OcrCallback() {
            @Override public void onText(String raw) {
                String cleaned = cleanText(raw, mode);
                if (cleaned.trim().length() < 1 && prepared != crop) {
                    prepared.recycle();
                    recognize(crop, mode, new OcrCallback() {
                        @Override public void onText(String raw2) {
                            String cleaned2 = cleanText(raw2, mode);
                            if (cleaned2.trim().length() < 1) {
                                callback.onError("No se detectó texto dentro del cuadro.");
                                return;
                            }
                            translateFixedOrDetected(cleaned2, mode, callback);
                        }
                        @Override public void onError(String error) { callback.onError(error); }
                    });
                    return;
                }
                if (prepared != crop) prepared.recycle();
                if (cleaned.trim().length() < 1) {
                    callback.onError("No se detectó texto dentro del cuadro.");
                    return;
                }
                translateFixedOrDetected(cleaned, mode, callback);
            }

            @Override public void onError(String error) {
                if (prepared != crop) prepared.recycle();
                callback.onError(error);
            }
        });
    }

    private void processAuto(Bitmap crop, Callback callback) {
        Bitmap prepared = prepareForOcr(crop);
        List<Candidate> candidates = new ArrayList<>();
        String[] modes = new String[]{ MODE_ENGLISH, MODE_CHINESE, MODE_JAPANESE, MODE_KOREAN };
        recognizeAutoAt(prepared, modes, 0, candidates, () -> {
            Candidate best = chooseBest(candidates);
            if (prepared != crop) prepared.recycle();

            if (best == null || best.cleaned.trim().length() < 1) {
                // Segundo intento con la imagen original por si el contraste dañó el OCR.
                List<Candidate> fallback = new ArrayList<>();
                recognizeAutoAt(crop, modes, 0, fallback, () -> {
                    Candidate best2 = chooseBest(fallback);
                    if (best2 == null || best2.cleaned.trim().length() < 1) {
                        callback.onError("No se detectó texto dentro del cuadro.");
                        return;
                    }
                    translate(best2.cleaned, best2.sourceLanguage, callback);
                });
                return;
            }
            translate(best.cleaned, best.sourceLanguage, callback);
        });
    }

    private void recognizeAutoAt(Bitmap bitmap, String[] modes, int index, List<Candidate> out, Runnable done) {
        if (index >= modes.length) {
            done.run();
            return;
        }
        String mode = modes[index];
        recognize(bitmap, mode, new OcrCallback() {
            @Override public void onText(String raw) {
                String cleaned = cleanText(raw, mode);
                int score = scoreCandidate(cleaned, mode);
                if (cleaned.trim().length() > 0) {
                    out.add(new Candidate(cleaned, mode, score));
                }
                recognizeAutoAt(bitmap, modes, index + 1, out, done);
            }

            @Override public void onError(String error) {
                // En Auto no molestamos por un OCR que falle; probamos el siguiente idioma.
                recognizeAutoAt(bitmap, modes, index + 1, out, done);
            }
        });
    }

    private Candidate chooseBest(List<Candidate> candidates) {
        Candidate best = null;
        for (Candidate c : candidates) {
            if (best == null || c.score > best.score) best = c;
        }
        return best;
    }

    private int scoreCandidate(String text, String mode) {
        if (text == null) return 0;
        String t = text.trim();
        if (t.length() == 0) return 0;
        int score = Math.min(t.length(), 160);
        int cjk = countMatches(cjkPattern, t);
        int chinese = countMatches(chinesePattern, t);
        int japanese = countMatches(japanesePattern, t);
        int korean = countMatches(koreanPattern, t);
        int latin = countMatches(latinPattern, t);

        if (MODE_ENGLISH.equals(mode)) {
            score += latin * 3;
            if (cjk > 0) score -= cjk * 2;
        } else if (MODE_CHINESE.equals(mode)) {
            score += chinese * 7;
            if (japanese > 0 || korean > 0) score -= 10;
        } else if (MODE_JAPANESE.equals(mode)) {
            score += japanese * 8 + chinese * 2;
        } else if (MODE_KOREAN.equals(mode)) {
            score += korean * 8;
        }
        return score;
    }

    private int countMatches(Pattern pattern, String text) {
        int count = 0;
        java.util.regex.Matcher m = pattern.matcher(text);
        while (m.find()) count++;
        return count;
    }

    private static class Candidate {
        final String cleaned;
        final String sourceLanguage;
        final int score;
        Candidate(String cleaned, String sourceLanguage, int score) {
            this.cleaned = cleaned;
            this.sourceLanguage = sourceLanguage;
            this.score = score;
        }
    }

    private Bitmap prepareForOcr(Bitmap crop) {
        if (crop == null || crop.isRecycled()) return crop;
        int width = crop.getWidth();
        int height = crop.getHeight();
        if (width <= 0 || height <= 0) return crop;

        // Escala el recorte para que el OCR lea mejor subtítulos pequeños.
        float scale = 1.0f;
        if (width < 1100) scale = 2.0f;
        if (width < 680) scale = 2.6f;
        if (width < 430) scale = 3.0f;
        int newW = Math.max(width, Math.round(width * scale));
        int newH = Math.max(height, Math.round(height * scale));

        Bitmap scaled = Bitmap.createScaledBitmap(crop, newW, newH, true);
        Bitmap enhanced = Bitmap.createBitmap(newW, newH, Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(enhanced);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        float contrast = 1.48f;
        float translate = (-0.5f * contrast + 0.5f) * 255f;
        ColorMatrix matrix = new ColorMatrix(new float[]{
                contrast, 0, 0, 0, translate,
                0, contrast, 0, 0, translate,
                0, 0, contrast, 0, translate,
                0, 0, 0, 1, 0
        });
        paint.setColorFilter(new ColorMatrixColorFilter(matrix));
        canvas.drawBitmap(scaled, 0, 0, paint);
        if (scaled != crop) scaled.recycle();
        return enhanced;
    }

    private interface OcrCallback {
        void onText(String text);
        void onError(String error);
    }

    private void recognize(Bitmap crop, String mode, OcrCallback cb) {
        TextRecognizer recognizer = createRecognizer(mode);
        InputImage image = InputImage.fromBitmap(crop, 0);
        recognizer.process(image)
                .addOnSuccessListener(result -> {
                    String text = result.getText();
                    recognizer.close();
                    cb.onText(text);
                })
                .addOnFailureListener(e -> {
                    recognizer.close();
                    cb.onError("Error OCR: " + e.getMessage());
                });
    }

    private TextRecognizer createRecognizer(String mode) {
        if (MODE_CHINESE.equals(mode)) {
            return TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        }
        if (MODE_JAPANESE.equals(mode)) {
            return TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
        }
        if (MODE_KOREAN.equals(mode)) {
            return TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
        }
        return TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    private void translateFixedOrDetected(String text, String mode, Callback callback) {
        if (!MODE_AUTO.equals(mode)) {
            translate(text, mode, callback);
            return;
        }
        detectLanguageThenTranslate(text, callback);
    }

    private void detectLanguageThenTranslate(String text, Callback callback) {
        String guessed = guessFromCharacters(text);
        if (guessed != null) {
            translate(text, guessed, callback);
            return;
        }

        LanguageIdentifier identifier = LanguageIdentification.getClient();
        identifier.identifyLanguage(text)
                .addOnSuccessListener(languageCode -> {
                    String src = mapLanguage(languageCode);
                    if (src == null || "und".equals(languageCode)) src = TranslateLanguage.ENGLISH;
                    translate(text, src, callback);
                })
                .addOnFailureListener(e -> translate(text, TranslateLanguage.ENGLISH, callback));
    }

    private void translate(String text, String sourceLanguage, Callback callback) {
        String src = sourceLanguage;
        if (MODE_AUTO.equals(src)) src = guessFromCharacters(text);
        if (src == null) src = TranslateLanguage.ENGLISH;

        String cleanForTranslate = normalizeBeforeTranslate(text, src);

        if (TranslateLanguage.SPANISH.equals(src)) {
            callback.onSuccess(cleanForTranslate, cleanForTranslate, "Español");
            return;
        }
        if (TranslateLanguage.ENGLISH.equals(src)) {
            String direct = fallbackEnglishToSpanish(cleanForTranslate);
            if (direct != null && direct.trim().length() > 0) {
                callback.onSuccess(cleanForTranslate, direct, readable(src));
                return;
            }
        }

        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(src)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build();
        Translator translator = Translation.getClient(options);
        final String finalSrc = src;
        final String finalInput = cleanForTranslate;
        translator.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(unused -> translator.translate(finalInput)
                        .addOnSuccessListener(translated -> {
                            translator.close();
                            String polished = polishSpanish(translated);
                            if (looksUntranslated(finalInput, polished) && TranslateLanguage.ENGLISH.equals(finalSrc)) {
                                String fallback = fallbackEnglishToSpanish(finalInput);
                                if (fallback != null && fallback.trim().length() > 0) polished = fallback;
                            }
                            callback.onSuccess(finalInput, polished, readable(finalSrc));
                        })
                        .addOnFailureListener(e -> {
                            translator.close();
                            callback.onError("Error al traducir: " + e.getMessage());
                        }))
                .addOnFailureListener(e -> {
                    translator.close();
                    callback.onError("Falta modelo offline. Abre con internet y toca Preparar offline para " + readable(finalSrc) + " → Español.");
                });
    }

    private String normalizeBeforeTranslate(String text, String sourceLanguage) {
        if (text == null) return "";
        String t = text.replace("\r", " ").replace("\n", " ").replaceAll("\\s+", " ").trim();
        if (TranslateLanguage.ENGLISH.equals(sourceLanguage)) {
            t = repairEnglishOcr(t);
        }
        return t;
    }

    private String repairEnglishOcr(String text) {
        if (text == null) return "";
        String t = text.trim();
        t = stripCjkFromEnglish(t);
        // Une subtítulos con OCR pegado: "athome" debe llegar al traductor como "at home".
        t = t.replaceAll("(?<=[a-z])(?=[A-Z])", " ");
        t = t.replace('’', '\'');
        t = t.replaceAll("(?i)\\bdothes\\b", "clothes");
        t = t.replaceAll("(?i)\\bclathes\\b", "clothes");
        t = t.replaceAll("(?i)\\bputyour\\b", "put your");
        t = t.replaceAll("(?i)\\byourclothes\\b", "your clothes");
        t = t.replaceAll("(?i)\\bathome\\b", "at home");
        t = t.replaceAll("(?i)\\batschool\\b", "at school");
        t = t.replaceAll("(?i)\\batwork\\b", "at work");
        t = t.replaceAll("(?i)\\binthe\\b", "in the");
        t = t.replaceAll("(?i)\\bonthe\\b", "on the");
        t = t.replaceAll("(?i)\\bofthe\\b", "of the");
        t = t.replaceAll("(?i)\\btothe\\b", "to the");
        t = t.replaceAll("(?i)\\bforthe\\b", "for the");
        t = t.replaceAll("(?i)\\bfromthe\\b", "from the");
        t = t.replaceAll("(?i)\\bwiththe\\b", "with the");
        t = t.replaceAll("(?i)\\bandthe\\b", "and the");
        t = t.replaceAll("(?i)\\bisnot\\b", "is not");
        t = t.replaceAll("(?i)\\barenot\\b", "are not");
        t = t.replaceAll("(?i)\\bdonot\\b", "do not");
        t = t.replaceAll("(?i)\\bdidnt\\b", "did not");
        t = t.replaceAll("(?i)\\bdoesnt\\b", "does not");
        t = t.replaceAll("(?i)\\bdont\\b", "do not");
        t = t.replaceAll("(?i)\\bcant\\b", "can not");
        t = t.replaceAll("(?i)\\bcannot\\b", "can not");
        t = t.replaceAll("(?i)\\bwont\\b", "will not");
        t = t.replaceAll("(?i)\\bim\\b", "I am");
        t = t.replaceAll("(?i)\\byoure\\b", "you are");
        t = t.replaceAll("(?i)\\bhes\\b", "he is");
        t = t.replaceAll("(?i)\\bshes\\b", "she is");
        t = t.replaceAll("(?i)\\btheyre\\b", "they are");
        t = t.replaceAll("(?i)\\bwere\\b", "we are");
        t = t.replaceAll("[.]{2,}", " ");
        t = t.replaceAll("[^A-Za-z0-9'.,?!:;\\- ]+", " ");
        return t.replaceAll("\\s+", " ").trim();
    }

    private String stripCjkFromEnglish(String text) {
        if (text == null) return "";
        String t = text;
        // Quita traducciones chinas/japonesas/coreanas entre paréntesis para no contaminar el inglés.
        t = t.replaceAll("\\([^)]*[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF][^)]*\\)", " ");
        t = t.replaceAll("[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF]+", " ");
        return t;
    }

    private String cleanEnglishLine(String line) {
        if (line == null) return "";
        String s = repairEnglishOcr(line);
        s = s.replaceAll("^[^A-Za-z0-9¿¡]+", "");
        s = s.replaceAll("[^A-Za-z0-9.?!']+$", "");
        return s.replaceAll("\\s+", " ").trim();
    }

    private boolean isGoodEnglishLine(String s) {
        if (s == null) return false;
        String key = normalizeKey(s);
        if (key.length() < 2) return false;
        int words = countEnglishWords(s);
        if (words >= 2) return true;
        return key.equals("at home") || key.equals("thank you");
    }

    private int countEnglishWords(String s) {
        if (s == null) return 0;
        java.util.regex.Matcher m = Pattern.compile("[A-Za-z]{2,}").matcher(s);
        int count = 0;
        while (m.find()) count++;
        return count;
    }

    private String cleanCjkLine(String line) {
        if (line == null) return "";
        String s = line;
        // Si hay inglés + CJK en una misma línea, conserva la parte CJK para OCR chino/japonés/coreano.
        s = s.replaceAll("[A-Za-z0-9][A-Za-z0-9'.,?!:;\\- ]+", " ");
        s = s.replaceAll("[()\\[\\]{}]", " ");
        s = s.replaceAll("\\s+", " ").trim();
        return s;
    }

    private boolean looksUntranslated(String original, String translated) {
        if (original == null || translated == null) return false;
        String a = normalizeKey(original);
        String b = normalizeKey(translated);
        if (a.length() == 0 || b.length() == 0) return false;
        return a.equals(b) || (b.contains(a) && b.length() <= a.length() + 4);
    }

    private String fallbackEnglishToSpanish(String text) {
        String k = normalizeKey(text);
        if (k.equals("at home")) return "En casa";
        if (k.equals("i am at home")) return "Estoy en casa";
        if (k.equals("i m at home")) return "Estoy en casa";
        if (k.equals("i am at school")) return "Estoy en la escuela";
        if (k.equals("i am at work")) return "Estoy en el trabajo";
        if (k.equals("good morning")) return "Buenos días";
        if (k.equals("good night")) return "Buenas noches";
        if (k.equals("thank you")) return "Gracias";
        if (k.equals("what are you doing")) return "¿Qué estás haciendo?";
        if (k.equals("where are you")) return "¿Dónde estás?";
        if (k.contains("put your clothes on")) return "Ponte la ropa.";
        if (k.contains("so i pretend i do not know anything") || k.contains("so i pretend i dont know anything")) return "Así que finjo que no sé nada.";
        return null;
    }

    private String normalizeKey(String text) {
        if (text == null) return "";
        return text.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9áéíóúñü]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private String cleanText(String raw, String mode) {
        if (raw == null) return "";
        String[] lines = raw.replace("\r", "").split("\n");
        StringBuilder cjk = new StringBuilder();
        StringBuilder all = new StringBuilder();
        StringBuilder english = new StringBuilder();

        for (String line : lines) {
            String s = line.trim();
            if (s.length() == 0) continue;
            String lower = s.toLowerCase(Locale.ROOT);
            if (isWatermarkOrUi(s, lower)) continue;

            if (MODE_ENGLISH.equals(mode)) {
                String e = cleanEnglishLine(s);
                if (isGoodEnglishLine(e)) english.append(e).append('\n');
                continue;
            }

            if (MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode)) {
                String onlyCjk = cleanCjkLine(s);
                if (cjkPattern.matcher(onlyCjk).find()) {
                    cjk.append(onlyCjk).append('\n');
                    continue;
                }
            }
            all.append(s).append('\n');
        }

        if (MODE_ENGLISH.equals(mode) && english.length() > 0) {
            return english.toString().trim();
        }
        // Para idiomas CJK, preferimos solo caracteres chinos/japoneses/coreanos si existe.
        if ((MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode)) && cjk.length() > 0) {
            return cjk.toString().trim();
        }
        return all.toString().trim();
    }

    private boolean isWatermarkOrUi(String s, String lower) {
        return lower.contains("video eagle")
                || lower.contains("tencent")
                || lower.contains("zeta live translator")
                || lower.contains("ocr solo")
                || lower.contains("order by")
                || lower.contains("date added")
                || lower.contains("date published")
                || lower.contains("popular:")
                || lower.contains("mother language")
                || lower.contains("spanish order")
                || lower.contains("auto") && lower.contains("español")
                || lower.contains("chino") && lower.contains("es")
                || lower.contains("inglés") && lower.contains("es")
                || lower.contains("japonés") && lower.contains("es")
                || lower.contains("coreano") && lower.contains("es")
                || lower.equals("área")
                || lower.equals("trad.")
                || lower.equals("vivo")
                || lower.equals("pausa")
                || lower.equals("ok")
                || s.contains("腾讯视频")
                || s.contains("出品")
                || s.contains("云曦星空")
                || s.contains("AI专属");
    }

    private String polishSpanish(String translated) {
        if (translated == null) return "";
        String t = translated.replace("\r", " ").replace("\n", " ").replaceAll("\\s+", " ").trim();
        if (t.length() == 0) return t;
        return t.substring(0, 1).toUpperCase(Locale.ROOT) + t.substring(1);
    }

    private String guessFromCharacters(String text) {
        if (text == null) return null;
        if (koreanPattern.matcher(text).find()) return TranslateLanguage.KOREAN;
        if (japanesePattern.matcher(text).find()) return TranslateLanguage.JAPANESE;
        if (chinesePattern.matcher(text).find()) return TranslateLanguage.CHINESE;
        if (latinPattern.matcher(text).find()) return TranslateLanguage.ENGLISH;
        return null;
    }

    private String mapLanguage(String languageCode) {
        if (languageCode == null) return null;
        if (languageCode.startsWith("zh")) return TranslateLanguage.CHINESE;
        if (languageCode.startsWith("en")) return TranslateLanguage.ENGLISH;
        if (languageCode.startsWith("ja")) return TranslateLanguage.JAPANESE;
        if (languageCode.startsWith("ko")) return TranslateLanguage.KOREAN;
        if (languageCode.startsWith("es")) return TranslateLanguage.SPANISH;
        return null;
    }

    public String readable(String code) {
        if (TranslateLanguage.CHINESE.equals(code)) return "Chino";
        if (TranslateLanguage.ENGLISH.equals(code)) return "Inglés";
        if (TranslateLanguage.JAPANESE.equals(code)) return "Japonés";
        if (TranslateLanguage.KOREAN.equals(code)) return "Coreano";
        if (TranslateLanguage.SPANISH.equals(code)) return "Español";
        return code == null ? "Auto" : code;
    }
}
