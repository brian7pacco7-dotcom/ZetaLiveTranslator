package com.geozeta.livetranslator;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 501;
    private static final int REQ_NOTIFICATIONS = 502;

    private TextView status;
    private ProgressBar progress;
    private Button prepareBtn;
    private Button startBtn;

    private final List<String> offlineSources = Arrays.asList(
            TranslateLanguage.CHINESE,
            TranslateLanguage.ENGLISH,
            TranslateLanguage.JAPANESE,
            TranslateLanguage.KOREAN
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        requestNotificationPermissionIfNeeded();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = dp(22);
        root.setPadding(pad, dp(34), pad, pad);
        root.setBackgroundColor(0xFFF8F7FC);

        TextView title = new TextView(this);
        title.setText("Zeta Live Translator");
        title.setTextSize(26);
        title.setTextColor(0xFF111827);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("Traduce subtítulos dentro de un cuadro seleccionado.\nPrimero descarga modelos con internet; después traduce sin conexión.");
        sub.setTextSize(15);
        sub.setTextColor(0xFF374151);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.setMargins(0, dp(12), 0, dp(22));
        root.addView(sub, subLp);

        prepareBtn = makeButton("1. Preparar offline");
        prepareBtn.setOnClickListener(v -> prepareOfflineModels());
        root.addView(prepareBtn, buttonLp());

        Button overlayBtn = makeButton("2. Permiso sobre otras apps");
        overlayBtn.setOnClickListener(v -> requestOverlayPermission());
        root.addView(overlayBtn, buttonLp());

        startBtn = makeButton("3. Iniciar traductor");
        startBtn.setOnClickListener(v -> startCaptureFlow());
        root.addView(startBtn, buttonLp());

        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams pLp = new LinearLayout.LayoutParams(dp(42), dp(42));
        pLp.setMargins(0, dp(18), 0, dp(8));
        root.addView(progress, pLp);

        status = new TextView(this);
        status.setText("Listo. Usa primero internet para preparar los idiomas.");
        status.setTextSize(14);
        status.setTextColor(0xFF4B5563);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setTextColor(0xFFFFFFFF);
        b.setAllCaps(false);
        b.setBackgroundColor(0xFF7C3AED);
        return b;
    }

    private LinearLayout.LayoutParams buttonLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.setMargins(0, dp(8), 0, dp(8));
        return lp;
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } else {
            toast("Permiso de superposición ya está activo.");
        }
    }

    private void startCaptureFlow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            toast("Primero activa el permiso sobre otras apps.");
            requestOverlayPermission();
            return;
        }
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(manager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, OverlayTranslatorService.class);
                service.putExtra(OverlayTranslatorService.EXTRA_RESULT_CODE, resultCode);
                service.putExtra(OverlayTranslatorService.EXTRA_DATA, data);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(service);
                } else {
                    startService(service);
                }
                toast("Traductor iniciado. Ajusta el cuadro sobre el subtítulo.");
                moveTaskToBack(true);
            } else {
                toast("Permiso de captura cancelado.");
            }
        }
    }

    private void prepareOfflineModels() {
        prepareBtn.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        status.setText("Descargando modelos para usar sin internet...");
        downloadModelAt(0);
    }

    private void downloadModelAt(int index) {
        if (index >= offlineSources.size()) {
            progress.setVisibility(View.GONE);
            prepareBtn.setEnabled(true);
            status.setText("Listo. Modelos preparados: Chino/Inglés/Japonés/Coreano → Español.");
            toast("Modelos listos. Ya puedes usarlo sin internet.");
            return;
        }

        String source = offlineSources.get(index);
        status.setText("Descargando: " + readable(source) + " → Español...");
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(source)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build();
        Translator translator = Translation.getClient(options);
        translator.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(unused -> {
                    translator.close();
                    downloadModelAt(index + 1);
                })
                .addOnFailureListener(e -> {
                    translator.close();
                    progress.setVisibility(View.GONE);
                    prepareBtn.setEnabled(true);
                    status.setText("No se pudo descargar " + readable(source) + ". Revisa internet y vuelve a intentar.");
                    toast("Fallo descarga: " + e.getMessage());
                });
    }

    private String readable(String code) {
        if (TranslateLanguage.CHINESE.equals(code)) return "Chino";
        if (TranslateLanguage.ENGLISH.equals(code)) return "Inglés";
        if (TranslateLanguage.JAPANESE.equals(code)) return "Japonés";
        if (TranslateLanguage.KOREAN.equals(code)) return "Coreano";
        return code;
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
