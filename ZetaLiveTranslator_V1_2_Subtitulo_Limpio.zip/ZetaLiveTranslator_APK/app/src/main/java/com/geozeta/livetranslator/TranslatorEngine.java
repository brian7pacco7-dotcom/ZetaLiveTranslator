package com.geozeta.livetranslator;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.Locale;
import java.util.regex.Pattern;

public class TranslatorEngine {
    public static final String MODE_AUTO = "auto";
    public static final String MODE_CHINESE = TranslateLanguage.CHINESE;
    public static final String MODE_ENGLISH = TranslateLanguage.ENGLISH;
    public static final String MODE_JAPANESE = TranslateLanguage.JAPANESE;
    public static final String MODE_KOREAN = TranslateLanguage.KOREAN;

    public interface Callback {
        void onSuccess(String original, String translated, String sourceName);
        void onError(String message);
    }

    private final Pattern cjkPattern = Pattern.compile("[\\u3400-\\u9FFF\\u3040-\\u30FF\\uAC00-\\uD7AF]");

    public void process(Bitmap crop, String mode, Callback callback) {
        Bitmap prepared = prepareForOcr(crop);
        recognize(prepared, mode, new OcrCallback() {
            @Override public void onText(String raw) {
                String cleaned = cleanText(raw, mode);
                if (cleaned.trim().length() < 1 && prepared != crop) {
                    prepared.recycle();
                    // Segundo intento sin filtro: evita perder texto si el video tiene colores raros.
                    recognize(crop, mode, new OcrCallback() {
                        @Override public void onText(String raw2) {
                            String cleaned2 = cleanText(raw2, mode);
                            if (cleaned2.trim().length() < 1) {
                                callback.onError("No se detectó texto dentro del cuadro. Agranda el área o pausa el video.");
                                return;
                            }
                            detectLanguageThenTranslate(cleaned2, mode, callback);
                        }
                        @Override public void onError(String error) { callback.onError(error); }
                    });
                    return;
                }
                if (prepared != crop) prepared.recycle();
                if (cleaned.trim().length() < 1) {
                    callback.onError("No se detectó texto dentro del cuadro. Agranda el área o pausa el video.");
                    return;
                }
                detectLanguageThenTranslate(cleaned, mode, callback);
            }
            @Override public void onError(String error) {
                if (prepared != crop) prepared.recycle();
                callback.onError(error);
            }
        });
    }

    private Bitmap prepareForOcr(Bitmap crop) {
        if (crop == null || crop.isRecycled()) return crop;
        int width = crop.getWidth();
        int height = crop.getHeight();
        if (width <= 0 || height <= 0) return crop;

        // Escala el recorte para que el OCR lea mejor subtítulos pequeños.
        float scale = 1.0f;
        if (width < 900) scale = 2.2f;
        if (width < 520) scale = 2.8f;
        int newW = Math.max(width, Math.round(width * scale));
        int newH = Math.max(height, Math.round(height * scale));

        Bitmap scaled = Bitmap.createScaledBitmap(crop, newW, newH, true);
        Bitmap enhanced = Bitmap.createBitmap(newW, newH, Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(enhanced);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        float contrast = 1.38f;
        float translate = (-0.5f * contrast + 0.5f) * 255f;
        ColorMatrix matrix = new ColorMatrix(new float[]{
                contrast, 0, 0, 0, translate,
                0, contrast, 0, 0, translate,
                0, 0, contrast, 0, translate,
                0, 0, 0, 1, 0
        });
        paint.setColorFilter(new ColorMatrixColorFilter(matrix));
        canvas.drawBitmap(scaled, 0, 0, paint);
        if (scaled != crop) scaled.recycle();
        return enhanced;
    }

    private interface OcrCallback {
        void onText(String text);
        void onError(String error);
    }

    private void recognize(Bitmap crop, String mode, OcrCallback cb) {
        TextRecognizer recognizer = createRecognizer(mode);
        InputImage image = InputImage.fromBitmap(crop, 0);
        recognizer.process(image)
                .addOnSuccessListener(result -> {
                    String text = result.getText();
                    recognizer.close();
                    if (MODE_AUTO.equals(mode) && text.trim().length() < 2) {
                        recognizeWithLatin(crop, cb);
                    } else {
                        cb.onText(text);
                    }
                })
                .addOnFailureListener(e -> {
                    recognizer.close();
                    cb.onError("Error OCR: " + e.getMessage());
                });
    }

    private void recognizeWithLatin(Bitmap crop, OcrCallback cb) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        InputImage image = InputImage.fromBitmap(crop, 0);
        recognizer.process(image)
                .addOnSuccessListener((Text result) -> {
                    String text = result.getText();
                    recognizer.close();
                    cb.onText(text);
                })
                .addOnFailureListener(e -> {
                    recognizer.close();
                    cb.onError("Error OCR Latin: " + e.getMessage());
                });
    }

    private TextRecognizer createRecognizer(String mode) {
        if (MODE_CHINESE.equals(mode) || MODE_AUTO.equals(mode)) {
            return TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        }
        if (MODE_JAPANESE.equals(mode)) {
            return TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
        }
        if (MODE_KOREAN.equals(mode)) {
            return TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
        }
        return TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    private void detectLanguageThenTranslate(String text, String mode, Callback callback) {
        if (!MODE_AUTO.equals(mode)) {
            translate(text, mode, callback);
            return;
        }

        String guessed = guessFromCharacters(text);
        if (guessed != null) {
            translate(text, guessed, callback);
            return;
        }

        LanguageIdentifier identifier = LanguageIdentification.getClient();
        identifier.identifyLanguage(text)
                .addOnSuccessListener(languageCode -> {
                    String src = mapLanguage(languageCode);
                    if (src == null || "und".equals(languageCode)) {
                        src = TranslateLanguage.ENGLISH;
                    }
                    translate(text, src, callback);
                })
                .addOnFailureListener(e -> translate(text, TranslateLanguage.ENGLISH, callback));
    }

    private void translate(String text, String sourceLanguage, Callback callback) {
        if (TranslateLanguage.SPANISH.equals(sourceLanguage)) {
            callback.onSuccess(text, text, "Español");
            return;
        }
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(sourceLanguage)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build();
        Translator translator = Translation.getClient(options);
        translator.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(unused -> translator.translate(text)
                        .addOnSuccessListener(translated -> {
                            translator.close();
                            callback.onSuccess(text, polishSpanish(translated), readable(sourceLanguage));
                        })
                        .addOnFailureListener(e -> {
                            translator.close();
                            callback.onError("Error al traducir: " + e.getMessage());
                        }))
                .addOnFailureListener(e -> {
                    translator.close();
                    callback.onError("Falta modelo offline. Entra con internet y toca Preparar offline para " + readable(sourceLanguage) + " → Español.");
                });
    }

    private String cleanText(String raw, String mode) {
        if (raw == null) return "";
        String[] lines = raw.replace("\r", "").split("\n");
        StringBuilder cjk = new StringBuilder();
        StringBuilder all = new StringBuilder();

        for (String line : lines) {
            String s = line.trim();
            if (s.length() == 0) continue;
            String lower = s.toLowerCase(Locale.ROOT);
            if (isWatermarkOrUi(s, lower)) continue;

            if (MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode) || MODE_AUTO.equals(mode)) {
                if (cjkPattern.matcher(s).find()) {
                    cjk.append(s).append('\n');
                    continue;
                }
            }
            all.append(s).append('\n');
        }

        if ((MODE_CHINESE.equals(mode) || MODE_JAPANESE.equals(mode) || MODE_KOREAN.equals(mode) || MODE_AUTO.equals(mode)) && cjk.length() > 0) {
            return cjk.toString().trim();
        }
        return all.toString().trim();
    }

    private boolean isWatermarkOrUi(String s, String lower) {
        return lower.contains("video eagle")
                || lower.contains("tencent")
                || lower.contains("zeta live translator")
                || lower.contains("ocr solo")
                || lower.contains("auto") && lower.contains("español")
                || s.contains("腾讯视频")
                || s.contains("出品")
                || s.contains("云曦星空")
                || s.contains("AI专属");
    }

    private String polishSpanish(String translated) {
        if (translated == null) return "";
        String t = translated.replace("\r", " ").replace("\n", " ").replaceAll("\\s+", " ").trim();
        if (t.length() == 0) return t;
        return t.substring(0, 1).toUpperCase(Locale.ROOT) + t.substring(1);
    }

    private String guessFromCharacters(String text) {
        if (text == null) return null;
        if (Pattern.compile("[\\uAC00-\\uD7AF]").matcher(text).find()) return TranslateLanguage.KOREAN;
        if (Pattern.compile("[\\u3040-\\u30FF]").matcher(text).find()) return TranslateLanguage.JAPANESE;
        if (Pattern.compile("[\\u3400-\\u9FFF]").matcher(text).find()) return TranslateLanguage.CHINESE;
        return null;
    }

    private String mapLanguage(String languageCode) {
        if (languageCode == null) return null;
        if (languageCode.startsWith("zh")) return TranslateLanguage.CHINESE;
        if (languageCode.startsWith("en")) return TranslateLanguage.ENGLISH;
        if (languageCode.startsWith("ja")) return TranslateLanguage.JAPANESE;
        if (languageCode.startsWith("ko")) return TranslateLanguage.KOREAN;
        if (languageCode.startsWith("es")) return TranslateLanguage.SPANISH;
        return null;
    }

    public String readable(String code) {
        if (TranslateLanguage.CHINESE.equals(code)) return "Chino";
        if (TranslateLanguage.ENGLISH.equals(code)) return "Inglés";
        if (TranslateLanguage.JAPANESE.equals(code)) return "Japonés";
        if (TranslateLanguage.KOREAN.equals(code)) return "Coreano";
        if (TranslateLanguage.SPANISH.equals(code)) return "Español";
        return code == null ? "Auto" : code;
    }
}
