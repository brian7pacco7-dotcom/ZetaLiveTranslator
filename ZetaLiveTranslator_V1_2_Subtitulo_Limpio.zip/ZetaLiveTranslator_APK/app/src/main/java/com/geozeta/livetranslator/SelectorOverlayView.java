package com.geozeta.livetranslator;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

public class SelectorOverlayView extends View {
    public interface OnRectChangedListener { void onRectChanged(Rect rect); }

    private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handle = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handleInner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private OnRectChangedListener listener;

    private float lastX;
    private float lastY;
    private int mode = 0; // 0 none, 1 drag, 2 resize, 3 create
    private final float minWidth;
    private final float minHeight;
    private final float handleSize;

    public SelectorOverlayView(Context context, Rect initial) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        minWidth = dp(120);
        minHeight = dp(44);
        handleSize = dp(13);

        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(dp(2));
        border.setColor(Color.rgb(124, 58, 237));
        border.setShadowLayer(dp(3), 0, 0, Color.argb(180, 0, 0, 0));

        handle.setStyle(Paint.Style.FILL);
        handle.setColor(Color.rgb(124, 58, 237));
        handle.setShadowLayer(dp(3), 0, 0, Color.argb(180, 0, 0, 0));

        handleInner.setStyle(Paint.Style.FILL);
        handleInner.setColor(Color.WHITE);

        setRect(initial);
    }

    public void setOnRectChangedListener(OnRectChangedListener listener) {
        this.listener = listener;
    }

    public void setRect(Rect r) {
        rect.set(r.left, r.top, r.right, r.bottom);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // Cuadro totalmente vacío: no oscurece ni tapa el video.
        canvas.drawRoundRect(rect, dp(4), dp(4), border);
        drawHandle(canvas, rect.left, rect.top);
        drawHandle(canvas, rect.centerX(), rect.top);
        drawHandle(canvas, rect.right, rect.top);
        drawHandle(canvas, rect.left, rect.centerY());
        drawHandle(canvas, rect.right, rect.centerY());
        drawHandle(canvas, rect.left, rect.bottom);
        drawHandle(canvas, rect.centerX(), rect.bottom);
        drawHandle(canvas, rect.right, rect.bottom);
    }

    private void drawHandle(Canvas canvas, float x, float y) {
        canvas.drawCircle(x, y, handleSize / 2f, handle);
        canvas.drawCircle(x, y, handleSize / 4f, handleInner);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = x;
                lastY = y;
                if (nearResizeHandle(x, y)) {
                    mode = 2;
                } else if (rect.contains(x, y)) {
                    mode = 1;
                } else {
                    mode = 3;
                    rect.set(x, y, x + minWidth, y + minHeight);
                }
                notifyRect();
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (mode == 1) {
                    float dx = x - lastX;
                    float dy = y - lastY;
                    rect.offset(dx, dy);
                    clampRect();
                } else if (mode == 2) {
                    rect.right = Math.max(rect.left + minWidth, x);
                    rect.bottom = Math.max(rect.top + minHeight, y);
                    clampRect();
                } else if (mode == 3) {
                    rect.right = x;
                    rect.bottom = y;
                    normalizeRect();
                    clampRect();
                }
                lastX = x;
                lastY = y;
                notifyRect();
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                mode = 0;
                normalizeRect();
                clampRect();
                notifyRect();
                invalidate();
                return true;
        }
        return true;
    }

    private boolean nearResizeHandle(float x, float y) {
        return Math.abs(x - rect.right) <= dp(36) && Math.abs(y - rect.bottom) <= dp(36);
    }

    private void normalizeRect() {
        float left = Math.min(rect.left, rect.right);
        float right = Math.max(rect.left, rect.right);
        float top = Math.min(rect.top, rect.bottom);
        float bottom = Math.max(rect.top, rect.bottom);
        if (right - left < minWidth) right = left + minWidth;
        if (bottom - top < minHeight) bottom = top + minHeight;
        rect.set(left, top, right, bottom);
    }

    private void clampRect() {
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        if (rect.width() > w) rect.right = rect.left + w;
        if (rect.height() > h) rect.bottom = rect.top + h;
        if (rect.left < 0) rect.offset(-rect.left, 0);
        if (rect.top < 0) rect.offset(0, -rect.top);
        if (rect.right > w) rect.offset(w - rect.right, 0);
        if (rect.bottom > h) rect.offset(0, h - rect.bottom);
    }

    private void notifyRect() {
        if (listener != null) {
            listener.onRectChanged(new Rect(
                    Math.round(rect.left),
                    Math.round(rect.top),
                    Math.round(rect.right),
                    Math.round(rect.bottom)
            ));
        }
    }

    private float dp(int value) {
        return value * getResources().getDisplayMetrics().density;
    }
}
