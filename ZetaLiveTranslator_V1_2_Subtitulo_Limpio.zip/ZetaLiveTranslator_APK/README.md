# Zeta Live Translator V1.2

APK Android para traducir subtítulos de videos usando un área seleccionada.

## Cambios V1.2

- Cuadro vacío y transparente: no tapa el video.
- El usuario puede dibujar/mover/agrandar el área libremente.
- OCR únicamente dentro del cuadro seleccionado.
- El panel y el cuadro se ocultan antes de capturar para no leerse a sí mismos.
- Después de traducir desaparece el cuadro y la traducción queda como subtítulo.
- Modo por defecto: Chino → Español.
- Botón para cambiar a Auto/Inglés/Japonés/Coreano → Español.
- Mejora del OCR: escalado y contraste del recorte antes de leer texto.
- Filtro de marcas de agua comunes: Tencent, Video Eagle, textos de UI.
- Descarga inicial de modelos para funcionar offline después.

## Uso

1. Abrir app con internet.
2. Tocar **Preparar offline**.
3. Activar permiso sobre otras apps.
4. Iniciar traductor.
5. Dibujar el cuadro sobre el subtítulo.
6. Tocar **OK**.
7. Tocar **Trad.** o **Vivo**.

## Nota

La calidad final depende de que el subtítulo esté visible, pausado o estable, con buen tamaño y dentro del cuadro. El flujo de la app está preparado para recortar solo el área seleccionada y traducirla.
