# Zeta Live Translator V1.12

Versión corregida para traducir subtítulos sobre otras apps.

## Cambios V1.12

- Modo **Auto → Español** por defecto.
- OCR probado por idioma: Inglés, Chino, Japonés y Coreano.
- Se quitó el aviso grande de “No se detectó texto” para que no moleste en video.
- El cuadro ya no se recrea por accidente al tocar fuera.
- El cuadro se mueve tocando dentro y arrastrando.
- El cuadro se estira desde cualquiera de los puntos morados.
- Después de traducir, desaparece el cuadro y queda solo el subtítulo.
- Primera vez: usar internet y tocar **Preparar offline** para descargar modelos.

## Uso rápido

1. Abrir la app con internet.
2. Tocar **Preparar offline**.
3. Activar **Permiso sobre otras apps**.
4. Tocar **Iniciar traductor**.
5. En el video tocar **Área**.
6. Mover o estirar el cuadro sobre el subtítulo.
7. Tocar **OK**.
8. Tocar **Trad.** o **Vivo**.

Si el texto no aparece, no saldrá aviso grande en medio; solo ajusta el cuadro más cerca del subtítulo o pausa el video.


NOVEDAD V1.12:
- Subtítulo con fondo negro semitransparente y letras blancas.
- El cuadro ya no se recrea al tocar fuera; solo se mueve o estira.
- Traducción Auto→Español para Inglés, Chino, Japonés y Coreano.


NOVEDAD V1.12:
- El subtítulo ya no parpadea por ocultarse durante la captura.
- Puedes arrastrar el subtítulo y colocarlo donde quieras.
- Botón Ocultar/Mostrar para dar prioridad al video.
- La barra superior sigue movible.


NOVEDAD V1.12 TRADUCCIÓN:
- Prioriza la línea en inglés cuando hay inglés + chino al mismo tiempo, porque traduce mejor a español.
- Limpia OCR pegado y errores comunes: athome→at home, dothes→clothes, wheres→where is.
- Evita releer el subtítulo español propio como texto original.
- Filtros para no agarrar títulos raros o marcas si hay una frase real de subtítulo.


NOVEDAD V1.12:
- Corrige el error donde el OCR podía leer el subtítulo de la misma app o un título falso como "Scratchman Curse".
- Las ventanas flotantes usan FLAG_SECURE para que no se capturen como texto original.
- En Auto se rechazan falsos positivos cortos/títulos cuando hay subtítulos reales.
- Prioridad: traducción correcta antes que apariencia.
