ZETA LIVE TRANSLATOR V1

QUE HACE ESTA V1:
- Muestra un cuadro flotante encima de videos, páginas, galería o imágenes.
- Mueves el cuadro sobre el texto/subtítulo.
- Pausas el video.
- Tocas Traducir.
- Lee solo la zona del cuadro, traduce al español y muestra el resultado ahí mismo.
- No guarda capturas en la galería.
- La primera vez necesita internet para descargar modelos de idioma.
- Después funciona offline con los modelos descargados.

IMPORTANTE:
- Android siempre pedirá permiso para capturar pantalla.
- Android mostrará una notificación porque el servicio no puede ser oculto.
- En apps que bloquean captura puede salir negro.
- Esta es V1. Si GitHub marca error, mándame captura del error y te mando ZIP corregido.

COMO USAR EN EL CELULAR:
1. Instala el APK generado por GitHub Actions.
2. Abre Zeta Live Translator.
3. Toca: Dar permiso para aparecer encima.
4. Activa el permiso.
5. Vuelve a la app y toca: Iniciar cuadro traductor.
6. Acepta el permiso de captura de pantalla.
7. Abre tu video, página o imagen.
8. Pausa cuando salga el texto.
9. Pon el cuadro morado encima del texto.
10. Toca Traducir.

COMO COMPILAR SIN DESCOMPRIMIR ZIP:
1. En GitHub crea el archivo:
   .github/workflows/build-apk-from-zip.yml
2. Pega el contenido del archivo build-apk-from-zip.yml que te mandé.
3. Sube este ZIP a la raíz del repositorio.
4. En GitHub entra a Actions.
5. Abre Build APK from ZIP.
6. Descarga el artifact ZetaLiveTranslator_APK.
