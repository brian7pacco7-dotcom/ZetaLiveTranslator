package com.zeta.livetranslator;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.tasks.Task;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class OverlayTranslatorService extends Service {
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";

    private static final String CHANNEL_ID = "zeta_live_translator_channel";
    private static final int NOTIFICATION_ID = 5601;

    private WindowManager windowManager;
    private FrameLayout overlayBox;
    private WindowManager.LayoutParams overlayParams;
    private TextView resultText;
    private Button translateButton;
    private TextView chipText;
    private TextView closeButton;
    private View resizeHandle;
    private Handler mainHandler;

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private int screenWidth;
    private int screenHeight;
    private int densityDpi;
    private boolean isWorking = false;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mainHandler = new Handler(Looper.getMainLooper());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        setupDisplayMetrics();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startAsForeground();
        if (intent == null) return START_NOT_STICKY;

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        Intent resultData;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        } else {
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        }

        if (resultCode != 0 && resultData != null) {
            startCapture(resultCode, resultData);
            showOverlay();
        }
        return START_STICKY;
    }

    private void startAsForeground() {
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(com.zeta.livetranslator.R.drawable.ic_launcher)
                .setContentTitle("Zeta Live Translator activo")
                .setContentText("Cuadro flotante listo para traducir texto en pantalla.")
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void setupDisplayMetrics() {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        densityDpi = metrics.densityDpi;
    }

    private void startCapture(int resultCode, Intent resultData) {
        releaseCapture();
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        mediaProjection = manager.getMediaProjection(resultCode, resultData);
        if (mediaProjection == null) return;

        mediaProjection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                mainHandler.post(() -> {
                    setResult("Captura detenida. Vuelve a iniciar desde la app.");
                    releaseCapture();
                });
            }
        }, mainHandler);

        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "ZetaLiveTranslatorCapture",
                screenWidth,
                screenHeight,
                densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(),
                null,
                mainHandler
        );
    }

    private void showOverlay() {
        if (overlayBox != null) return;

        overlayBox = new FrameLayout(this);
        overlayBox.setPadding(dp(10), dp(8), dp(10), dp(10));
        overlayBox.setBackground(makeBoxBackground());

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        overlayBox.addView(content, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        content.addView(topRow, new LinearLayout.LayoutParams(-1, dp(38)));

        chipText = new TextView(this);
        chipText.setText("Auto → Español  •  En vivo");
        chipText.setTextColor(0xFFFFFFFF);
        chipText.setTextSize(13);
        chipText.setGravity(Gravity.CENTER_VERTICAL);
        chipText.setPadding(dp(8), 0, dp(8), 0);
        topRow.addView(chipText, new LinearLayout.LayoutParams(0, -1, 1));

        closeButton = new TextView(this);
        closeButton.setText("✕");
        closeButton.setTextColor(0xFFFFFFFF);
        closeButton.setTextSize(20);
        closeButton.setGravity(Gravity.CENTER);
        closeButton.setOnClickListener(v -> stopSelf());
        topRow.addView(closeButton, new LinearLayout.LayoutParams(dp(42), -1));

        translateButton = new Button(this);
        translateButton.setText("Traducir");
        translateButton.setAllCaps(false);
        translateButton.setTextColor(0xFFFFFFFF);
        translateButton.setTextSize(15);
        translateButton.setBackgroundColor(0xFF7C3AED);
        translateButton.setOnClickListener(v -> translateSelectedArea());
        content.addView(translateButton, new LinearLayout.LayoutParams(-1, dp(46)));

        resultText = new TextView(this);
        resultText.setText("Pausa el video, coloca este cuadro sobre el texto y toca Traducir.");
        resultText.setTextColor(0xFFFFFFFF);
        resultText.setTextSize(15);
        resultText.setGravity(Gravity.CENTER);
        resultText.setPadding(dp(8), dp(8), dp(8), dp(8));
        content.addView(resultText, new LinearLayout.LayoutParams(-1, 0, 1));

        resizeHandle = new View(this);
        GradientDrawable handleBg = new GradientDrawable();
        handleBg.setShape(GradientDrawable.RECTANGLE);
        handleBg.setCornerRadius(dp(8));
        handleBg.setColor(0xFF8B5CF6);
        resizeHandle.setBackground(handleBg);
        FrameLayout.LayoutParams handleParams = new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.BOTTOM | Gravity.RIGHT);
        handleParams.setMargins(0, 0, dp(2), dp(2));
        overlayBox.addView(resizeHandle, handleParams);

        attachMoveAndResizeListeners();

        overlayParams = new WindowManager.LayoutParams(
                Math.min(screenWidth - dp(32), dp(360)),
                dp(190),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        overlayParams.gravity = Gravity.TOP | Gravity.LEFT;
        overlayParams.x = dp(16);
        overlayParams.y = Math.max(dp(120), (int) (screenHeight * 0.56f));
        windowManager.addView(overlayBox, overlayParams);
    }

    private void attachMoveAndResizeListeners() {
        final int[] startX = new int[1];
        final int[] startY = new int[1];
        final float[] touchX = new float[1];
        final float[] touchY = new float[1];

        overlayBox.setOnTouchListener((v, event) -> {
            if (isWorking) return true;
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX[0] = overlayParams.x;
                    startY[0] = overlayParams.y;
                    touchX[0] = event.getRawX();
                    touchY[0] = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    overlayParams.x = startX[0] + (int) (event.getRawX() - touchX[0]);
                    overlayParams.y = startY[0] + (int) (event.getRawY() - touchY[0]);
                    clampOverlayPosition();
                    windowManager.updateViewLayout(overlayBox, overlayParams);
                    return true;
            }
            return false;
        });

        resizeHandle.setOnTouchListener(new View.OnTouchListener() {
            int startW;
            int startH;
            float startRawX;
            float startRawY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startW = overlayParams.width;
                        startH = overlayParams.height;
                        startRawX = event.getRawX();
                        startRawY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        overlayParams.width = clamp(startW + (int) (event.getRawX() - startRawX), dp(210), screenWidth - dp(16));
                        overlayParams.height = clamp(startH + (int) (event.getRawY() - startRawY), dp(135), screenHeight - dp(60));
                        windowManager.updateViewLayout(overlayBox, overlayParams);
                        return true;
                }
                return false;
            }
        });
    }

    private void translateSelectedArea() {
        if (isWorking) return;
        if (imageReader == null) {
            setResult("No hay captura activa. Reinicia desde la app.");
            return;
        }
        isWorking = true;
        translateButton.setEnabled(false);
        setResult("Leyendo texto...");

        int[] loc = new int[2];
        overlayBox.getLocationOnScreen(loc);
        Rect cropRect = new Rect(loc[0], loc[1], loc[0] + overlayBox.getWidth(), loc[1] + overlayBox.getHeight());
        cropRect.intersect(0, 0, screenWidth, screenHeight);

        // Oculta el cuadro un instante para que el OCR no lea los botones de la propia app.
        overlayBox.setVisibility(View.INVISIBLE);
        mainHandler.postDelayed(() -> {
            Bitmap screen = acquireLatestBitmap();
            overlayBox.setVisibility(View.VISIBLE);
            if (screen == null) {
                finishWorking("No pude leer la pantalla. Pausa el video e intenta otra vez.");
                return;
            }
            Bitmap cropped = safeCrop(screen, cropRect);
            screen.recycle();
            if (cropped == null) {
                finishWorking("La zona marcada no es válida.");
                return;
            }
            runOcr(cropped);
        }, 260);
    }

    private Bitmap acquireLatestBitmap() {
        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) return null;
            int width = image.getWidth();
            int height = image.getHeight();
            Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            int rowPadding = rowStride - pixelStride * width;
            Bitmap bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
            bitmap.copyPixelsFromBuffer(buffer);
            return Bitmap.createBitmap(bitmap, 0, 0, width, height);
        } catch (Exception e) {
            return null;
        } finally {
            if (image != null) image.close();
        }
    }

    private Bitmap safeCrop(Bitmap source, Rect rect) {
        try {
            int left = clamp(rect.left, 0, source.getWidth() - 1);
            int top = clamp(rect.top, 0, source.getHeight() - 1);
            int right = clamp(rect.right, left + 1, source.getWidth());
            int bottom = clamp(rect.bottom, top + 1, source.getHeight());
            return Bitmap.createBitmap(source, left, top, right - left, bottom - top);
        } catch (Exception e) {
            return null;
        }
    }

    private void runOcr(Bitmap bitmap) {
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        List<TextRecognizer> recognizers = new ArrayList<>();
        recognizers.add(TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS));
        recognizers.add(TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build()));
        recognizers.add(TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build()));
        recognizers.add(TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build()));
        runRecognizerAt(0, recognizers, image, "", bitmap);
    }

    private void runRecognizerAt(int index, List<TextRecognizer> recognizers, InputImage image, String bestText, Bitmap bitmap) {
        if (index >= recognizers.size()) {
            for (TextRecognizer r : recognizers) {
                try { r.close(); } catch (Exception ignored) {}
            }
            bitmap.recycle();
            String clean = cleanText(bestText);
            if (clean.length() < 2) {
                finishWorking("No detecté texto claro. Agranda el cuadro o pausa mejor el video.");
            } else {
                translateText(clean);
            }
            return;
        }
        TextRecognizer recognizer = recognizers.get(index);
        Task<Text> task = recognizer.process(image);
        task.addOnSuccessListener(text -> {
            String found = text.getText() == null ? "" : text.getText().trim();
            String nextBest = found.length() > bestText.length() ? found : bestText;
            runRecognizerAt(index + 1, recognizers, image, nextBest, bitmap);
        }).addOnFailureListener(e -> runRecognizerAt(index + 1, recognizers, image, bestText, bitmap));
    }

    private String cleanText(String raw) {
        return raw.replace("Traducir", "")
                .replace("Auto → Español", "")
                .replace("En vivo", "")
                .replace("Pausa el video", "")
                .trim();
    }

    private void translateText(String originalText) {
        setResult("Texto detectado:\n" + originalText + "\n\nDetectando idioma...");
        String localGuess = guessCjkLanguage(originalText);
        if (localGuess != null) {
            translateWithSource(originalText, localGuess);
            return;
        }
        LanguageIdentifier languageIdentifier = LanguageIdentification.getClient();
        languageIdentifier.identifyLanguage(originalText)
                .addOnSuccessListener(code -> {
                    languageIdentifier.close();
                    String source = mapLanguage(code);
                    if (source == null) source = TranslateLanguage.ENGLISH;
                    translateWithSource(originalText, source);
                })
                .addOnFailureListener(e -> {
                    languageIdentifier.close();
                    translateWithSource(originalText, TranslateLanguage.ENGLISH);
                });
    }

    private void translateWithSource(String originalText, String sourceLanguage) {
        if (TranslateLanguage.SPANISH.equals(sourceLanguage)) {
            finishWorking("Ya parece estar en español:\n\n" + originalText);
            return;
        }
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(sourceLanguage)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build();
        Translator translator = Translation.getClient(options);
        DownloadConditions conditions = new DownloadConditions.Builder().build();
        setResult("Preparando modelo offline...\nPrimera vez necesita internet. Luego funciona sin internet.");
        translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(v -> translator.translate(originalText)
                        .addOnSuccessListener(translated -> {
                            translator.close();
                            finishWorking(translated + "\n\nOriginal:\n" + originalText);
                        })
                        .addOnFailureListener(e -> {
                            translator.close();
                            finishWorking("No se pudo traducir. Revisa internet para descargar el modelo la primera vez.");
                        }))
                .addOnFailureListener(e -> {
                    translator.close();
                    finishWorking("Falta descargar el modelo de idioma. Conéctate a internet una vez y vuelve a tocar Traducir.");
                });
    }

    private String mapLanguage(String code) {
        if (code == null) return null;
        if (code.startsWith("en")) return TranslateLanguage.ENGLISH;
        if (code.startsWith("ja")) return TranslateLanguage.JAPANESE;
        if (code.startsWith("ko")) return TranslateLanguage.KOREAN;
        if (code.startsWith("zh")) return TranslateLanguage.CHINESE;
        if (code.startsWith("es")) return TranslateLanguage.SPANISH;
        if (code.startsWith("fr")) return TranslateLanguage.FRENCH;
        if (code.startsWith("de")) return TranslateLanguage.GERMAN;
        if (code.startsWith("it")) return TranslateLanguage.ITALIAN;
        if (code.startsWith("pt")) return TranslateLanguage.PORTUGUESE;
        if (code.startsWith("ru")) return TranslateLanguage.RUSSIAN;
        return null;
    }

    private String guessCjkLanguage(String text) {
        if (text.matches(".*[\\u3040-\\u30ff].*")) return TranslateLanguage.JAPANESE;
        if (text.matches(".*[\\uac00-\\ud7af].*")) return TranslateLanguage.KOREAN;
        if (text.matches(".*[\\u4e00-\\u9fff].*")) return TranslateLanguage.CHINESE;
        return null;
    }

    private void finishWorking(String message) {
        setResult(message);
        isWorking = false;
        translateButton.setEnabled(true);
    }

    private void setResult(String msg) {
        mainHandler.post(() -> {
            if (resultText != null) resultText.setText(msg);
        });
    }

    private GradientDrawable makeBoxBackground() {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xDD111827);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(2), 0xFF8B5CF6);
        return bg;
    }

    private void clampOverlayPosition() {
        overlayParams.x = clamp(overlayParams.x, -dp(10), screenWidth - dp(60));
        overlayParams.y = clamp(overlayParams.y, dp(24), screenHeight - dp(60));
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Zeta Live Translator",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Servicio necesario para traducir texto en pantalla.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void releaseCapture() {
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) {}
        try { if (imageReader != null) imageReader.close(); } catch (Exception ignored) {}
        try { if (mediaProjection != null) mediaProjection.stop(); } catch (Exception ignored) {}
        virtualDisplay = null;
        imageReader = null;
        mediaProjection = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            if (overlayBox != null) windowManager.removeView(overlayBox);
        } catch (Exception ignored) {}
        overlayBox = null;
        releaseCapture();
    }
}
