package com.zeta.livetranslator;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_CAPTURE = 1200;
    private TextView statusText;
    private MediaProjectionManager projectionManager;

    private final ActivityResultLauncher<String> notificationPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {});

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        buildUi();
        requestNotificationPermissionIfNeeded();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22), dp(34), dp(22), dp(22));
        root.setBackgroundColor(0xFF101018);

        TextView title = new TextView(this);
        title.setText("Zeta Live Translator");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("Traductor flotante para videos, páginas e imágenes.\nNo guarda capturas. Traduce usando el cuadro morado.");
        sub.setTextColor(0xFFE5E7EB);
        sub.setTextSize(15);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.setMargins(0, dp(14), 0, dp(22));
        root.addView(sub, subParams);

        Button overlayBtn = makeButton("1. Dar permiso para aparecer encima");
        overlayBtn.setOnClickListener(v -> openOverlayPermission());
        root.addView(overlayBtn, btnParams());

        Button startBtn = makeButton("2. Iniciar cuadro traductor");
        startBtn.setOnClickListener(v -> startTranslatorFlow());
        root.addView(startBtn, btnParams());

        Button stopBtn = makeButton("Detener traductor");
        stopBtn.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayTranslatorService.class));
            statusText.setText("Traductor detenido.");
        });
        root.addView(stopBtn, btnParams());

        statusText = new TextView(this);
        statusText.setTextColor(0xFFCBD5E1);
        statusText.setTextSize(14);
        statusText.setGravity(Gravity.CENTER);
        statusText.setText("Primero permite la superposición. Luego acepta la captura de pantalla de Android.");
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.setMargins(0, dp(18), 0, 0);
        root.addView(statusText, statusParams);

        setContentView(root);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundColor(0xFF7C3AED);
        return b;
    }

    private LinearLayout.LayoutParams btnParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54));
        p.setMargins(0, dp(8), 0, dp(8));
        return p;
    }

    private void openOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Permiso de superposición ya está activo", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivity(intent);
    }

    private void startTranslatorFlow() {
        if (!Settings.canDrawOverlays(this)) {
            statusText.setText("Falta permiso: aparecer encima de otras apps.");
            openOverlayPermission();
            return;
        }
        statusText.setText("Acepta el permiso de captura. La app NO guardará capturas.");
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                Intent serviceIntent = new Intent(this, OverlayTranslatorService.class);
                serviceIntent.putExtra(OverlayTranslatorService.EXTRA_RESULT_CODE, resultCode);
                serviceIntent.putExtra(OverlayTranslatorService.EXTRA_RESULT_DATA, data);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent);
                } else {
                    startService(serviceIntent);
                }
                statusText.setText("Listo. Abre tu video, pausa, mueve el cuadro y toca Traducir.");
            } else {
                statusText.setText("No se aceptó el permiso de captura.");
            }
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
